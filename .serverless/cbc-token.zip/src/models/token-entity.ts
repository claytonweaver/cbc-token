export interface TokenEntity {
    tokenKey: string;
    tokenValue: string;
}