export interface CreateTokenRequest {
    tokenKey: string;
    email: string;
    password: string;
}