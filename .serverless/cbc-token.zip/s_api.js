
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'cweaver',
  applicationName: 'cbc-token',
  appUid: 'LHpY4QQCpShMzFkDbv',
  orgUid: '3ebbb081-1b47-4a6c-9fc0-5e876320e815',
  deploymentUid: '9c1546a3-2df2-43ba-9566-d6a88305192d',
  serviceName: 'cbc-token',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'cbc-token-dev-api', timeout: 6 };

try {
  const userHandler = require('./dist/lambda.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}